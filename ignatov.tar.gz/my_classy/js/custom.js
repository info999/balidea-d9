jQuery("#block-my-classy-powered").before("<button class=\"click_button\" type=\"button\">Click Me!</button>");
jQuery("button.click_button").on( "click", function() {
  alert('drupal9-balidea');
} );
